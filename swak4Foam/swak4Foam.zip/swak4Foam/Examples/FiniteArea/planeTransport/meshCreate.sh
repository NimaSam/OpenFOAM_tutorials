#! /bin/bash

blockMesh

makeFaMesh
