#!/bin/bash
# Source tutorial run functions

potentialFoam -writep -noFunctionObjects

simpleFoam
