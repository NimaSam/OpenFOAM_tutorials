#! /bin/bash

ansysToFoam flange.ans -scale 0.001
