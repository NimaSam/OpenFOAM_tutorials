#! /bin/bash

blockMesh

blockMesh -region solid
