#! /bin/bash

blockMesh

blockMesh -region inChannel

blockMesh -region outChannel
