#! /bin/bash

pyFoamRunner.py --auto setFields
