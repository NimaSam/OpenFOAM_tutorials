#! /bin/bash

blockMesh

blockMesh -region plateHole
