#! /bin/bash

blockMesh

blockMesh -region leftHeater

blockMesh -region rightHeater

blockMesh -region bottomHeater
