#! /bin/bash

blockMesh

blockMesh -region inChannel
