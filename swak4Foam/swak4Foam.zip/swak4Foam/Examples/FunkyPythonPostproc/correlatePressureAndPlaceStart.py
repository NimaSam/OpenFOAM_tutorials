# import scipy.stats
from matplotlib import pyplot

times=[]
slopes=[]
offsets=[]

print dir()
