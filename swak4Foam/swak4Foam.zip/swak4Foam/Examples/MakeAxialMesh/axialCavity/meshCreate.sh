#! /bin/bash

blockMesh
makeAxialMesh -overwrite
