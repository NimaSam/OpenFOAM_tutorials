print("Lua writes nothing")
