#! /bin/bash

funkySetFields -time 0
