#! /bin/bash

funkySetFields -time 0
funkySetLagrangianField -time 0
