#! /bin/bash

blockMesh

topoSet
setsToZones
