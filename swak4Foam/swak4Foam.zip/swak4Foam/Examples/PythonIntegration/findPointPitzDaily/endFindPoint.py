
print "Saving plot to 'reversionPoint.png'"
figure.savefig('reversionPoint.png')
