#! /bin/bash

blockMesh

funkySetFields -time 0
