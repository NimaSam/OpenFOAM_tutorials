The 0/ field files contain nonsense patchFields. All interesting
work is done using the changeDictionaryDicts.
