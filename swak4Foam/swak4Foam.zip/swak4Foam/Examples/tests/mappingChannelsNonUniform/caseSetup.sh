#! /bin/bash

calcNonUniformOffsetsForMapped

funkySetFields -time 0
