import math

print "Initializing variables"

written=[]
lastWrite=0;
startedThisWrite=0