#! /bin/bash

blockMesh
cp save/boundary constant/polyMesh/
