#! /bin/bash

funkySetFields -time 0 -allowFunctionObjects -addDummyPhi
