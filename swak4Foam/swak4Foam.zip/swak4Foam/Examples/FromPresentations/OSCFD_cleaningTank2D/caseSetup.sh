#! /bin/bash

funkySetFields -functionPlugins MeshWave -time 0
